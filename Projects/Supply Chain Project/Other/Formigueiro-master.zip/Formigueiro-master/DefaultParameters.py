import math

alpha = 1
beta = 1
rho = 0.1
Q   = 1
tau0 = 1
q0 = 0.5
phi = 0.9
minPheromone = -math.inf
maxPheromone = math.inf

numAnts = 10
numIterations = 100

