<template>
    <div class="server_error_box">
       <div>
            <span class="fa fa-warning"></span>
            <span id="message">خطا در ارسال درخواست - مجددا تلاش نمایید</span>
       </div>
   </div>
</template>

<script>
export default {
    name:"ServerErrorMessage"
}
</script>

<style>

</style>