<template>
  <div id="desktop_layout_footer">
    <div id="c_footer">
      <div id="contacts2">
        <div id="contacts2_right_box">
          <div id="contacts2_right_box-card5"><!---->
            <div>
               شماره تماس  :
            </div>
            <div>
              <a href="tel:+989196548587">
                09196548587
              </a>
            </div>
          </div>
          <div id="contacts2_right_box-card6"><!---->
            <div>
               آدرس ایمیل :
            </div>
            <div>
              <a href="mailto:info@oncogene.ir">
                info@oncogene.ir
              </a>
            </div>
          </div>
          <div id="contacts2_right_box-card7"><!---->
            <div>
               ساعات پاسخگویی  :
            </div>
            <div>
              شنبه تا چهارشنبه ۸:۳۰ الی ۲۱ - پنجشنبه ۹ الی ۲۰
            </div>
          </div>
        </div>
      </div>
      <div id="line3">
        <div id="line3_right_box"><a target="_blank"><img id="line3_right_box-img6"
                                                          src="https://oncogenedev.ir/files/images/1629708254.png"></a>
          <a target="_blank"><img id="line3_right_box-img7"
                                  src="https://oncogenedev.ir/files/images/1629708254.png"></a> <a target="_blank"><img
              id="line3_right_box-img4" src="https://oncogenedev.ir/files/images/1629708254.png"></a></div>
        <div id="line3_left_box">
          <div id="line3_left_box-code1"><p style="margin-top: 15px;"> about footer </p></div>
        </div>
      </div>
      <div id="line4">
        <div id="line4-p2">
          کلیه حقوق مادی و معنوی این سایت متعلق به آنکوژن بوده و انتشـار هرگونــه از مطالـب آن صرفا با ذکر نـام منبـع
          مجاز می بـاشد
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>
<style scoped>
@import "../../assets/components/partials/footer/all.css";
</style>


