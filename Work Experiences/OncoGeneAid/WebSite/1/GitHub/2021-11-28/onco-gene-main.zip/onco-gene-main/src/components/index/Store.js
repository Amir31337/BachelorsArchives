export default {
    namespaced: true,
    state: () => ({
        send_form: false,
    }),
    mutations: {

    },
    actions: {

    }
}
