<?php


namespace Modules\faq\Repository;


use App\Repositories\BaseInterface;

interface CategoryRepositoryInterface extends BaseInterface
{
    public function all();

}
