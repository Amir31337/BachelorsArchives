Vue.component('full-calendar',require('./components/FullCalendar').default);
