<?php

return  array (
  'shop_name' => 'آنکوژن',
  'shop_icon' => 'files/images/1635333620.png',
  'keywords' => 'null',
  'description' => 'فروشگاه اینترنتی  ایده پردازان جوان',
  'login_url' => 'admin_login',
  'seller' => 'آنکوژن',
  'NationalID' => '10',
  'registration-number' => '1010',
  'economical-number' => '101010',
  'address' => 'تبریز باغمیشه نصر سوم کوچه آذرآبادگان دهم',
  'zip-code' => '1234567892',
  'phone' => '09141592083',
);