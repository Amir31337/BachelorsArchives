<?php

Route::get('app/payment/{order_id}','AppController@payment');
