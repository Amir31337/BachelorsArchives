<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ResetsPasswords;
use App\Lib\Mobile_Detect;
class ResetPasswordController extends Controller
{

    use ResetsPasswords;


}
