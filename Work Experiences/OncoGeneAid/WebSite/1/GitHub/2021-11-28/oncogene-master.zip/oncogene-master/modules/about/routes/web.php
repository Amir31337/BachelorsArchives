<?php

Route::get('/about','AboutController@about')->name('about');

