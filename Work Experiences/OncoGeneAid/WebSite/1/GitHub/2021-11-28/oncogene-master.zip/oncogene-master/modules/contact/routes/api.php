<?php


Route::post('contact','ApiController@store');
