<?php

return  array (
  'action_gateway' => 
  array (
    'mellat' => 'true',
  ),
  'gateway' => 'mellat',
);