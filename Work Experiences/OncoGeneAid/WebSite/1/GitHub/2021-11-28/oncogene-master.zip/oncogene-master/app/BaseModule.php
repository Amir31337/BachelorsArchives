<?php

namespace App;

class BaseModule
{
    public static function __set_state($an_array)
    {
        return $an_array;
    }
}
