<?php


namespace Modules\appointment\Repository;


class EloquentAppointmentRepository
{

}
