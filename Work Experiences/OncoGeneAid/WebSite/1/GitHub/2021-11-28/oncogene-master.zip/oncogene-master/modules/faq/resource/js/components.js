Vue.component('faq',require('./components/Faq').default);
Vue.component('mobile-faq',require('./components/MobileFaq').default);
Vue.component('faq-search',require('./components/FaqSearch').default);
