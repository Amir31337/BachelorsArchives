Vue.component('panel-message',require('./components/PanelMessage').default);
