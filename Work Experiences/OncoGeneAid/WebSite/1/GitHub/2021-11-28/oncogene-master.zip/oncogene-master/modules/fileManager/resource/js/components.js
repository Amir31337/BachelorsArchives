Vue.component('file-manager',require('./components/FileManager').default);
