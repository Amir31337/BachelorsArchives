<?php

namespace Modules\appointment\Repository;

interface AppointmentRepositoryInterface
{

}
